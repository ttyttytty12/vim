Github color scheme for vim
===========================

Derived from [Anthony Carapetis]' [vim-github-theme].

[Anthony Carapetis]: https://github.com/acarapetis
[vim-github-theme]: http://www.vim.org/scripts/script.php?script_id=2855

Install
-------

With [Vundle](https://github.com/gmarik/vundle):

    Bundle 'croaky/vim-colors-github'

License
-------

MIT
