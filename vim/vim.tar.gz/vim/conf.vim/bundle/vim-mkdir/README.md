# Mkdir

> Maggie! Don't even ask. Just bring it. Come on.

*-- Hot Rod*

## Installation

1. Use pathogen
2. Clone to `~/.vim/bundle/mkdir`

## Usage

~~~
:e this/does/not/exist/file.txt
:w
~~~

Smile when you are not presented with an error. In stead, notice that 
vim has automatically created the non-existent directory for you.
